# OTG
KIvy, Python3.8, Panda and numpy

Install numpy , kivy , panda  liberary
